SOURCE:  https://github.com/mamedev/mame/pull/7717
VERSION: MAME v0.236 (5e865af)
BUILD:   MINGW64=/mingw64 make -j$(nproc) SUBTARGET=tiny TOOLS=1
