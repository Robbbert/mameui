/***************************************************************************

	The Predators

    driver by Philip Bennett, Angelo Salese and David Haywood

    special thanks to Andrew Welburn


  This is an odd piece of hardware, a 4 screen, 4 player prototype game from
  Williams / QVS.

  The system consists of a main board, an 'SC' board, and 4 'slave' boards.

  It has a total of 11 Cpus(!) but the majority of these are for sound.

  main board: 1x 68k, 1x AM2910 (driving the game / blitter)
  SC board: 1x 8035 ( ?? unknown purpose)
  Each slave board: 2x 6802 (each driving one sound channel)

  The slave boards are divided into 2 sections, sound and video, the sections
  are isolated from each other.  Each slave board is identical.

  The main board has a direct bus cable connection to the video section of
  each slave.  The SC board has a direct bus cable connection to the sound
  section of each slave.  Another ribbon cable connects the main board to
  the SC board.

  The system can boot and display attract mode with just the 68k board and
  a single slave attached, all connections to the SC board, can be removed
  although you get no sound.

  The cabinets are marked as follows

  Player 1 - Hawk
  Player 2 - Falcon
  Player 3 - Eagle
  Player 4 - Condor

  Representing the name of the ship the player controls.

  The video system appears to be unique for a raster game.  All objects
  displayed on the screen are composed of lines being drawn at various
  angles!  The blitter roms define x/y co-ordinates (from a base offset)
  as well as an angle, colour and real length!  Sin/Cos lookup proms are
  then used for drawing calculations, plotting the requested line.  All
  line/object definitions are hardcoded in ROM.


 To do:

  - Properly fix line drawing algorithm, lengths of some lines still
    aren't 100% correct, there are one pixel errors in places, I need to
	understand what causes these.  It seeems even what would appear to be
	basic straight lines are affected in some cases.  Probably a sub-pixel
	rounding / precision thing.
	  - I've tried not clearing the sub-pixel counters between lines, it
	    doesn't help
	  - Roms are all verified good based on the printed checksums
	  - The errors are obvious even in simple places like the 'Top Predators'
	    text of the high score table

  - Emulate AM2910 using the microcode, this probably performs at least part
    of the blitter tasks (but maybe not the line drawing directly if the slave
	boards are actually doing this?)

  - Hook up the i8035. This communicates serially with an unknown device in each
    slave cabinet which polls the controls

  - Fix CVSD speech being cut-off (e.g. "You have terminated eag")


 Interesting Note:
  Main RAM contains a collision bitmap, if you render it the game looks like
  some mini version of space-war ;-)

***************************************************************************/

#include "emu.h"
#include "cpu/m68000/m68000.h"
#include "machine/6840ptm.h"
#include "cpu/mcs48/mcs48.h"
#include "cpu/m6800/m6800.h"
#include "machine/6821pia.h"
#include "sound/hc55516.h"
#include "sound/dac.h"
#include "rendlay.h"
#include "pred.lh"
#include "machine/nvram.h"
#include "debug/debugcon.h"
#include "debug/debugcmd.h"
#include "debug/debugcpu.h"

/*************************************
 *
 *  Definitions
 *
 *************************************/

struct screen_state
{
	UINT8	m_reg0;
	UINT16	m_reg1;
	UINT16	m_reg2;
	UINT8	m_reg3;
	UINT16	m_reg4;
	UINT16	m_xmin;
	UINT16	m_xmax;

	UINT8	*m_vram;
	UINT8	m_vram_page;	
	UINT8	*m_sincostable;
	UINT8	m_busy;
	UINT8	m_swap;
};


class pred_state : public driver_device
{
public:
	pred_state(const machine_config &mconfig, device_type type, const char *tag)
		:	driver_device(mconfig, type, tag),
			m_maincpu(*this, "maincpu"),
			m_palette(*this, "palette")
			{ }

	DECLARE_WRITE16_MEMBER( blit_param_w );
	DECLARE_WRITE16_MEMBER( blit_ctrl_w );

	DECLARE_READ16_MEMBER( williams_49way_port_hawk_r );
	DECLARE_READ16_MEMBER( williams_49way_port_eagle_r );
	DECLARE_READ16_MEMBER( williams_49way_port_condor_r );
	DECLARE_READ16_MEMBER( williams_49way_port_falcon_r );

	DECLARE_WRITE16_MEMBER( sound_cmd_hawk0_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_hawk1_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_falcon0_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_falcon1_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_eagle0_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_eagle1_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_condor0_w );
	DECLARE_WRITE16_MEMBER( sound_cmd_condor1_w );

	DECLARE_READ8_MEMBER( p1_r );
	DECLARE_READ8_MEMBER( p2_r );

	DECLARE_READ8_MEMBER( io_r );
	DECLARE_READ8_MEMBER( t1_r );

	DECLARE_READ8_MEMBER( io_c_r );	
	DECLARE_WRITE8_MEMBER( io_c_w );
	
	DECLARE_WRITE8_MEMBER( io_w );

	INTERRUPT_GEN_MEMBER( vblank_callback );
	TIMER_CALLBACK_MEMBER( draw_complete );

	DECLARE_WRITE_LINE_MEMBER( ptm_irq );

	DECLARE_PALETTE_INIT( pred );
    DECLARE_DRIVER_INIT( pred );
	virtual void video_start();
	virtual void machine_reset();

	screen_state	m_screen_state[4];
	UINT8			m_screen_irq_mask;

	UINT8			*m_blitdat1; // = machine.region("blitlength")->base();
	UINT8			*m_blitdat2; // = machine.region("blityoffs")->base();
	UINT8			*m_blitdat3; // = machine.region("blitattr")->base();
	UINT8			*m_blitdat4; // = machine.region("blitxoffs")->base();
	UINT8			*m_blitdat5; // = machine.region("blitcolour")->base();


	UINT32 screen_update_hawk(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect);
	UINT32 screen_update_falcon(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect);
	UINT32 screen_update_eagle(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect);
	UINT32 screen_update_condor(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect);
	void draw_screen(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect, int which);
	void draw_line(int screen, int startx, int starty, int valctab, int valstab, int length, int colour);
	void write_4bpp_pixel(int screen, int x, int y, UINT8 pix, int wrap);
	void execute_draw_cmd(int screen);

	void update_main_irqs(void);
	void draw_cmd_finished(int screen);

//private:
	required_device<m68000_device>	m_maincpu;
	required_device<palette_device> m_palette;
};



/*************************************
 *
 *  Video hardware
 *
 *************************************/

PALETTE_INIT_MEMBER( pred_state, pred )
{
	UINT8* proms[4];

	proms[0] = memregion("hawkproms")->base();
	proms[1] = memregion("falconproms")->base();
	proms[2] = memregion("eagleproms")->base();
	proms[3] = memregion("condorproms")->base();

	for (int j = 0; j < 4; ++j)
	{
		for (int i = 0; i < 32; ++i)
		{
			int r, g, b;
			int bit0, bit1, bit2, bit3;

			bit0 = (proms[j][i] >> 0) & 0x01;
			bit1 = (proms[j][i] >> 1) & 0x01;
			bit2 = (proms[j][i] >> 2) & 0x01;
			bit3 = (proms[j][i] >> 3) & 0x01;
			g = 0x0e * bit0 + 0x1f * bit1 + 0x43 * bit2 + 0x8f * bit3;
			bit0 = (proms[j][i] >> 4) & 0x01;
			bit1 = (proms[j][i] >> 5) & 0x01;
			bit2 = (proms[j][i] >> 6) & 0x01;
			bit3 = (proms[j][i] >> 7) & 0x01;
			r = 0x0e * bit0 + 0x1f * bit1 + 0x43 * bit2 + 0x8f * bit3;
			bit0 = (proms[j][i+0x20] >> 0) & 0x01;
			bit1 = (proms[j][i+0x20] >> 1) & 0x01;
			bit2 = (proms[j][i+0x20] >> 2) & 0x01;
			bit3 = (proms[j][i+0x20] >> 3) & 0x01;
			b = 0x0e * bit0 + 0x1f * bit1 + 0x43 * bit2 + 0x8f * bit3;

			m_palette->set_pen_color(i+j*32, rgb_t(r, g, b));
		}
	}
}


void pred_state::video_start()
{
	m_screen_state[0].m_vram = auto_alloc_array_clear(machine(), UINT8, 0x10000 * 2);
	m_screen_state[1].m_vram = auto_alloc_array_clear(machine(), UINT8, 0x10000 * 2);
	m_screen_state[2].m_vram = auto_alloc_array_clear(machine(), UINT8, 0x10000 * 2);
	m_screen_state[3].m_vram = auto_alloc_array_clear(machine(), UINT8, 0x10000 * 2);

	/* Avoid runtime string lookups */
	m_blitdat1 = memregion("blitlength")->base();
	m_blitdat2 = memregion("blityoffs")->base();
	m_blitdat3 = memregion("blitattr")->base();
	m_blitdat4 = memregion("blitxoffs")->base();
	m_blitdat5 = memregion("blitcolour")->base();

	m_screen_state[0].m_sincostable = memregion("hawksincos")->base();
	m_screen_state[1].m_sincostable = memregion("falconsincos")->base();
	m_screen_state[2].m_sincostable = memregion("eaglesincos")->base();
	m_screen_state[3].m_sincostable = memregion("condorsincos")->base();
}


UINT32 pred_state::screen_update_hawk(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect)
{
	draw_screen(screen, bitmap, cliprect, 0);
	return 0;
}

UINT32 pred_state::screen_update_falcon(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect)
{
	draw_screen(screen, bitmap, cliprect, 1);
	return 0;
}

UINT32 pred_state::screen_update_eagle(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect)
{
	draw_screen(screen, bitmap, cliprect, 2);
	return 0;
}

UINT32 pred_state::screen_update_condor(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect)
{
	draw_screen(screen, bitmap, cliprect, 3);
	return 0;
}


void pred_state::draw_screen(screen_device &screen, bitmap_ind16 &bitmap, const rectangle &cliprect, int which)
{
	int color_base = 16 + (32 * which);
	UINT8* vram = m_screen_state[which].m_vram + (m_screen_state[which].m_vram_page ? 0 : 0x10000);

	bitmap.fill(m_palette->black_pen(), cliprect);

	for (int y = cliprect.min_y; y <= cliprect.max_y; ++y)
	{
		UINT8 *src = &vram[y * 512/2 + cliprect.min_x/2];
		UINT16 *dest = &bitmap.pix16(y, cliprect.min_x);

		for (int x = cliprect.min_x; x <= cliprect.max_x; x += 2)
		{
			UINT8 color = *src++;

			*dest++ = ((color & 0xf0) >> 4) + color_base;
			*dest++ = ((color & 0x0f) >> 0) + color_base;
		}
	}
}


INTERRUPT_GEN_MEMBER(pred_state::vblank_callback)
{
	/* Handle any pending VRAM page swaps here */
	for (int i = 0; i < 4; ++i)
	{
		screen_state &s_state = m_screen_state[i];

		if (s_state.m_swap)
		{
			s_state.m_vram_page ^= 1;
			s_state.m_swap = 0;
			draw_cmd_finished(i);
		}
	}
}

void pred_state::draw_cmd_finished(int screen)
{
	m_screen_state[screen].m_busy = 0;
	update_main_irqs();
}

TIMER_CALLBACK_MEMBER( pred_state::draw_complete )
{
	draw_cmd_finished(param);
}


void pred_state::write_4bpp_pixel(int screen, int x, int y, UINT8 pix, int wrap)
{
	const int width = 512;
	const int height = 256;
	const screen_state &s_state = m_screen_state[screen];

	x -= 256;
	y -= 256;

	if (y < 0 || x < 0)
		return;

	if (y >= height || x >= width)
		return;

	if (x >= (s_state.m_xmin * 2) && x <= (s_state.m_xmax * 2))
	{
		pix &= 0xf;
		
		UINT8* vram = s_state.m_vram + (s_state.m_vram_page ? 0x10000 : 0);

		int offs = y * width / 2;
		offs += x / 2;

		if (x & 1)
			vram[offs] = (vram[offs] & 0xf0) | pix;
		else
			vram[offs] = (vram[offs] & 0x0f) | (pix << 4);
	}
}

/* TODO: This is inaccurate */
void pred_state::draw_line(int screen, int startx, int starty, int valctab, int valstab, int length, int colour)
{
	int drawx = 0, drawy = 0;

	for (int j = 0; j < length; ++j)
	{
		// pre-increment?! gives the best results this way so far...
		drawx += valctab;
		drawy += valstab;

		write_4bpp_pixel(screen, startx+(drawx/0x40), starty+(drawy/0x40), colour, 0);
	}
}

void pred_state::execute_draw_cmd(int screen)
{
	screen_state &s_state = m_screen_state[screen];

	UINT8 trigger = s_state.m_reg0;

	if (trigger == 0x12 || trigger == 0x1a || trigger == 0x22 || trigger == 0x2a)
	{
		/*
			VRAM clear?

			Valid parameters:

			* X
			* Size (always 1)
			* Source (always 0)
		*/

		UINT8* vram = s_state.m_vram + (s_state.m_vram_page ? 0x10000 : 0);

		/* Clear the active video page with respect to the clipping region */
		// TODO: Understand X parameter
		for (int y = 0; y < 256; ++y)
		{
			int bytes = (s_state.m_xmax - s_state.m_xmin) + 1;
			memset(&vram[y * 512/2 + s_state.m_xmin], 0, bytes);
		}

		s_state.m_busy = 1;

		// TODO
		machine().scheduler().timer_set(attotime::from_usec(5), timer_expired_delegate(FUNC(pred_state::draw_complete),this), screen);
	}
	else if (trigger == 0x32 || trigger == 0x37 || trigger == 0x3c || trigger == 0x41)
	{
		/*
			VRAM bank swap on VBLANK?

			Valid parameters:

			* Size (always 1)
		*/
		s_state.m_swap = 1;
		s_state.m_busy = 1;
	}
	else if (trigger == 0x46 || trigger == 0x48 || trigger == 0x4a || trigger == 0x4c)
	{
		/*
			Set clipping region?

			Valid parameters:

			* X
			* Y
			* Size (always 1)
		*/
		s_state.m_xmax = s_state.m_reg1;
		s_state.m_xmin = s_state.m_reg2;

		// TODO
		s_state.m_busy = 1;		
		machine().scheduler().timer_set(attotime::from_usec(1), timer_expired_delegate(FUNC(pred_state::draw_complete), this), screen);
	}
	else if (trigger == 0x4e || trigger == 0x56 || trigger == 0x5e || trigger == 0x66)
	{
		int blit_x = s_state.m_reg1;
		int blit_y = s_state.m_reg2;
		UINT16 blit_size = s_state.m_reg3;
		UINT16 blit_src = s_state.m_reg4;

		for (int i = 0; i < blit_size; ++i)
		{
			int offset = blit_src + i;
			UINT8 length = m_blitdat1[offset];
			INT8 extray = m_blitdat2[offset];
			UINT8 attr = m_blitdat3[offset];
			INT8 extrax = m_blitdat4[offset];
			UINT8 colour;

			/* Colour data is packed into half sized rom with 2 * 4 bits in each byte */
			if ((blit_src + i) & 1)
			{
				colour = m_blitdat5[offset >> 1] & 0xf0;
				colour >>= 4;
			}
			else
			{
				colour = m_blitdat5[offset >> 1] & 0x0f;
			}

		   /* (relative to vertical orientation)
				line drawing.. it's an actual angle!! upper 4 bits shown in diagram below

			  e     f    0   1      2
				-        -        -
				  \      |      /
			  d     \    |    /     3
					  \  |  /
						\|/
			  c <------- o -------> 4
						/|\
					  /  |  \
			  b     /    |    \     5
				  /      |      \
				-        -        -
			   a    9    8    7     6

			  note, the length attribute is NOT in pixels(!) it's the real line length

			*/

			int valctab = s_state.m_sincostable[(attr & 0xff)];
			int valstab = s_state.m_sincostable[(attr & 0xff) + 0x100];

			if (valctab & 0x80)
				valctab = -(valctab & 0x7f);
			else
				valctab &= 0x7f;

			if (valstab & 0x80)
				valstab = -(valstab & 0x7f);
			else
				valstab &= 0x7f;

			draw_line(screen, blit_x + extrax, blit_y + extray, valctab, valstab, length, colour);
		}

		// TODO
		s_state.m_busy = 1;
		machine().scheduler().timer_set(attotime::from_usec(5), timer_expired_delegate(FUNC(pred_state::draw_complete), this), screen);
	}
}


WRITE16_MEMBER( pred_state::blit_param_w )
{
	/*
		Each screen has its own blit registers:

		40,2,4,6 = Command and trigger (Byte)
		50,2,4,6 = Dest. Y (Word)
		60,2,4,6 = Dest. X (Word)
		70,2,4,6 = Size (Byte)
		80,2,4,6 = Image address (Word)
	*/

	int screen = offset & 7;

	if (screen > 3)
	{
		logerror("invalid blit screen! %d\n", screen);
		return;
	}

	screen_state &s_state = m_screen_state[screen];

	int byte_offset = (offset & 0xf8) << 1;

	switch (byte_offset)
	{
		case 0x40:
			s_state.m_reg0 = data;
			execute_draw_cmd(screen);
			break;

		case 0x50:
			s_state.m_reg1 = data;
			break;

		case 0x60:
			s_state.m_reg2 = data;
			break;

		case 0x70:
			s_state.m_reg3 = data;
			break;

		case 0x80:
			s_state.m_reg4 = data;
			break;

		default:
			printf("%04x %04x %04x\n", offset * 2, data, mem_mask);
			break;
	}
}


WRITE16_MEMBER( pred_state::blit_ctrl_w )
{
	m_screen_irq_mask = (data >> 8) & 0xf;
	update_main_irqs();
}


void pred_state::update_main_irqs(void)
{
	m_maincpu->set_input_line(2, ((m_screen_irq_mask & 1) && !m_screen_state[0].m_busy) ? ASSERT_LINE : CLEAR_LINE);
	m_maincpu->set_input_line(3, ((m_screen_irq_mask & 2) && !m_screen_state[1].m_busy) ? ASSERT_LINE : CLEAR_LINE);
	m_maincpu->set_input_line(4, ((m_screen_irq_mask & 4) && !m_screen_state[2].m_busy) ? ASSERT_LINE : CLEAR_LINE);
	m_maincpu->set_input_line(5, ((m_screen_irq_mask & 8) && !m_screen_state[3].m_busy) ? ASSERT_LINE : CLEAR_LINE);
}


/*************************************
 *
 *  Sound hardware
 *
 *************************************/

#define MCFG_WILLIAMS_PREDATORS_SOUND_ADD(_tag) \
	MCFG_DEVICE_ADD(_tag, WILLIAMS_PREDATORS_SOUND, 0) \

class williams_pred_sound_device :	public device_t,
									public device_mixer_interface
{
public:
	// construction/destruction
	williams_pred_sound_device(const machine_config &mconfig, const char *tag, device_t *owner, UINT32 clock);

	DECLARE_WRITE16_MEMBER(sound_w);
	DECLARE_WRITE_LINE_MEMBER(sound_irq);

	DECLARE_WRITE8_MEMBER(bank_w);

protected:
	// device-level overrides
	virtual machine_config_constructor device_mconfig_additions() const;
	virtual void device_start();
	virtual void device_reset();

private:

	// devices
	required_device<m6802_cpu_device>	m_cpu;
	required_device<pia6821_device>		m_pia;
	required_device<hc55516_device>		m_hc55516;
};

extern const device_type WILLIAMS_PREDATORS_SOUND = &device_creator<williams_pred_sound_device>;


static ADDRESS_MAP_START( cpu_map, AS_PROGRAM, 8, williams_pred_sound_device )
	AM_RANGE(0x0000, 0x07ff) AM_RAM
	AM_RANGE(0x1000, 0x1000) AM_WRITE(bank_w)
	AM_RANGE(0x2000, 0x2003) AM_DEVREADWRITE("pia", pia6821_device, read, write)
	AM_RANGE(0x8000, 0xbfff) AM_ROMBANK("bank0")
	AM_RANGE(0xc000, 0xffff) AM_ROMBANK("bank1")
ADDRESS_MAP_END


WRITE16_MEMBER( williams_pred_sound_device::sound_w )
{
	m_pia->porta_w(data);
	m_pia->ca1_w(0);
	m_pia->ca1_w(1);
}


WRITE8_MEMBER( williams_pred_sound_device::bank_w )
{
	membank("bank1")->set_entry(data & 1);
	membank("bank0")->set_entry((data >> 1) & 1);
}


WRITE_LINE_MEMBER( williams_pred_sound_device::sound_irq )
{
	int combined_state = m_pia->irq_a_state() | m_pia->irq_b_state();
	m_cpu->set_input_line(M6800_IRQ_LINE, combined_state ? ASSERT_LINE : CLEAR_LINE);
}

static MACHINE_CONFIG_FRAGMENT( williams_pred_sound )
	MCFG_CPU_ADD("cpu", M6802, XTAL_4MHz)
	MCFG_CPU_PROGRAM_MAP(cpu_map)

	MCFG_DEVICE_ADD("pia", PIA6821, 0)
	// TODO: What is connected to CB1?
	MCFG_PIA_WRITEPB_HANDLER(DEVWRITE8("dac", dac_device, write_unsigned8))
	MCFG_PIA_CA2_HANDLER(DEVWRITELINE("cvsd", hc55516_device, clock_w))
	MCFG_PIA_CB2_HANDLER(DEVWRITELINE("cvsd", hc55516_device, digit_w))
	MCFG_PIA_IRQA_HANDLER(WRITELINE(williams_pred_sound_device, sound_irq))
	MCFG_PIA_IRQB_HANDLER(WRITELINE(williams_pred_sound_device, sound_irq))

	MCFG_SOUND_ADD("cvsd", HC55516, 0)
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, DEVICE_SELF_OWNER, 0.80/4)

	MCFG_SOUND_ADD("dac", DAC, 0)
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, DEVICE_SELF_OWNER, 0.50/4)
MACHINE_CONFIG_END




williams_pred_sound_device::williams_pred_sound_device(const machine_config &mconfig, const char *tag, device_t *owner, UINT32 clock)
	: device_t(mconfig, WILLIAMS_PREDATORS_SOUND, "Williams Predators Sound Channel", tag, owner, clock, "wmspred", __FILE__),
	  device_mixer_interface(mconfig, *this),
	  m_cpu(*this, "cpu"),
	  m_pia(*this, "pia"),
	  m_hc55516(*this, "cvsd")
{
}


void williams_pred_sound_device::device_start()
{
	/* Configure ROM banking */
	membank("bank0")->configure_entries(0, 2, memregion("cpu")->base(), 0x4000);
	membank("bank1")->configure_entries(0, 2, memregion("cpu")->base() + 0x8000, 0x4000);
}



machine_config_constructor williams_pred_sound_device::device_mconfig_additions() const
{
	return MACHINE_CONFIG_NAME( williams_pred_sound );
}

void williams_pred_sound_device::device_reset()
{
	membank("bank0")->set_entry(0);
	membank("bank1")->set_entry(1);
}



/*************************************
 *
 *  Inputs
 *
 *************************************/

static const UINT8 translate49[7] = { 0x0, 0x1, 0x2, 0x7, 0xa, 0x9, 0x8 };

READ16_MEMBER( pred_state::williams_49way_port_hawk_r )
{
	return (translate49[ioport("hawksticky")->read() >> 4] << 4) | translate49[ioport("hawkstickx")->read() >> 4];
}

READ16_MEMBER( pred_state::williams_49way_port_falcon_r )
{
	return (translate49[ioport("falconsticky")->read() >> 4] << 4) | translate49[ioport("falconstickx")->read() >> 4];
}

READ16_MEMBER( pred_state::williams_49way_port_eagle_r )
{
	return (translate49[ioport("eaglesticky")->read() >> 4] << 4) | translate49[ioport("eaglestickx")->read() >> 4];
}

READ16_MEMBER( pred_state::williams_49way_port_condor_r )
{
	return (translate49[ioport("condorsticky")->read() >> 4] << 4) | translate49[ioport("condorstickx")->read() >> 4];
}

static INPUT_PORTS_START( pred )
   PORT_START("systeminp")
    PORT_DIPNAME( 0x0001, 0x0000, "Audit 4 (Condor)" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0001, DEF_STR( On ) )
    PORT_DIPNAME( 0x0002, 0x0000, "Audit 3 (Eagle)" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0002, DEF_STR( On ) )
    PORT_DIPNAME( 0x0004, 0x0000, "Audit 2 (Falcon)" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0004, DEF_STR( On ) )
    PORT_DIPNAME( 0x0008, 0x0000, "Audit 1 (Hawk)" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0008, DEF_STR( On ) )
    PORT_DIPNAME( 0x0010, 0x0000, "MemLock" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0010, DEF_STR( On ) )
    PORT_DIPNAME( 0x0020, 0x0000, "HighScore" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0020, DEF_STR( On ) )
	PORT_BIT( 0x40, IP_ACTIVE_HIGH, IPT_OTHER ) PORT_NAME("Advance") PORT_CODE(KEYCODE_F2)
    PORT_DIPNAME( 0x0080, 0x0080, "Auto Manual" )
    PORT_DIPSETTING(      0x0000, DEF_STR( Off ) )
    PORT_DIPSETTING(      0x0080, DEF_STR( On ) )

	PORT_START("hawkstickx") // read at 0x800008, see williams_49way_port_hawk_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_X ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10)  PORT_PLAYER(1) PORT_NAME("Player 1 Stick X")
	PORT_START("hawksticky") // read at 0x800008, see williams_49way_port_hawk_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_Y ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10) PORT_REVERSE  PORT_PLAYER(1) PORT_NAME("Player 1 Stick Y")


	PORT_START("hawkgeneral")
	PORT_BIT( 0x0001, IP_ACTIVE_HIGH, IPT_BUTTON1 ) PORT_PLAYER(1) // Fire
	PORT_BIT( 0x0002, IP_ACTIVE_HIGH, IPT_BUTTON2 ) PORT_PLAYER(1) // Pod
	PORT_BIT( 0x0004, IP_ACTIVE_HIGH, IPT_BUTTON3 ) PORT_PLAYER(1) // Thrust
	PORT_BIT( 0x0008, IP_ACTIVE_HIGH, IPT_UNKNOWN )	// unused?
    PORT_BIT( 0x0010, IP_ACTIVE_HIGH, IPT_COIN9 ) PORT_NAME("Player 1 Right Coin")
    PORT_BIT( 0x0020, IP_ACTIVE_HIGH, IPT_COIN5 ) PORT_NAME("Player 1 Center Coin")
    PORT_BIT( 0x0040, IP_ACTIVE_HIGH, IPT_COIN1 ) PORT_NAME("Player 1 Left Coin")
    PORT_BIT( 0x0080, IP_ACTIVE_HIGH, IPT_TILT1 ) // slam??

	PORT_START("falconstickx") // read at 0x80000c, see williams_49way_port_falcon_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_X ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10)  PORT_PLAYER(2) PORT_NAME("Player 2 Stick X")
	PORT_START("falconsticky") // read at 0x80000c, see williams_49way_port_falcon_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_Y ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10) PORT_REVERSE  PORT_PLAYER(2) PORT_NAME("Player 2 Stick Y")

	PORT_START("falcongeneral")
	PORT_BIT( 0x0001, IP_ACTIVE_HIGH, IPT_BUTTON1 ) PORT_PLAYER(2) // Fire
	PORT_BIT( 0x0002, IP_ACTIVE_HIGH, IPT_BUTTON2 ) PORT_PLAYER(2) // Pod
	PORT_BIT( 0x0004, IP_ACTIVE_HIGH, IPT_BUTTON3 ) PORT_PLAYER(2) // Thrust
	PORT_BIT( 0x0008, IP_ACTIVE_HIGH, IPT_UNKNOWN )	// unused?
    PORT_BIT( 0x0010, IP_ACTIVE_HIGH, IPT_COIN10) PORT_NAME("Player 2 Right Coin")
    PORT_BIT( 0x0020, IP_ACTIVE_HIGH, IPT_COIN6 ) PORT_NAME("Player 2 Center Coin")
    PORT_BIT( 0x0040, IP_ACTIVE_HIGH, IPT_COIN2 ) PORT_NAME("Player 2 Left Coin")
    PORT_BIT( 0x0080, IP_ACTIVE_HIGH, IPT_TILT2 ) // slam??

	PORT_START("eaglestickx") // read at 0x800010, see williams_49way_port_eagle_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_X ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10)  PORT_PLAYER(3) PORT_NAME("Player 3 Stick X")
	PORT_START("eaglesticky") // read at 0x800010, see williams_49way_port_eagle_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_Y ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10) PORT_REVERSE  PORT_PLAYER(3) PORT_NAME("Player 3 Stick Y")

   PORT_START("eaglegeneral")
	PORT_BIT( 0x0001, IP_ACTIVE_HIGH, IPT_BUTTON1 ) PORT_PLAYER(3) // Fire
	PORT_BIT( 0x0002, IP_ACTIVE_HIGH, IPT_BUTTON2 ) PORT_PLAYER(3) // Pod
	PORT_BIT( 0x0004, IP_ACTIVE_HIGH, IPT_BUTTON3 ) PORT_PLAYER(3) // Thrust
	PORT_BIT( 0x0008, IP_ACTIVE_HIGH, IPT_UNKNOWN )	// unused?
    PORT_BIT( 0x0010, IP_ACTIVE_HIGH, IPT_COIN11) PORT_NAME("Player 3 Right Coin")
    PORT_BIT( 0x0020, IP_ACTIVE_HIGH, IPT_COIN7 ) PORT_NAME("Player 3 Center Coin")
    PORT_BIT( 0x0040, IP_ACTIVE_HIGH, IPT_COIN3 ) PORT_NAME("Player 3 Left Coin")
    PORT_BIT( 0x0080, IP_ACTIVE_HIGH, IPT_TILT3 )  // slam??

	PORT_START("condorstickx") // read at 0x800014, see williams_49way_port_condor_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_X ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10)  PORT_PLAYER(4) PORT_NAME("Player 4 Stick X")
	PORT_START("condorsticky") // read at 0x800014, see williams_49way_port_condor_r
	PORT_BIT( 0xff, 0x38, IPT_AD_STICK_Y ) PORT_MINMAX(0x00,0x6f) PORT_SENSITIVITY(100) PORT_KEYDELTA(10) PORT_REVERSE PORT_PLAYER(4) PORT_NAME("Player 4 Stick Y")


   PORT_START("condorgeneral")
	PORT_BIT( 0x0001, IP_ACTIVE_HIGH, IPT_BUTTON1 ) PORT_PLAYER(4) // Fire
	PORT_BIT( 0x0002, IP_ACTIVE_HIGH, IPT_BUTTON2 ) PORT_PLAYER(4) // Pod
	PORT_BIT( 0x0004, IP_ACTIVE_HIGH, IPT_BUTTON3 ) PORT_PLAYER(4) // Thrust
	PORT_BIT( 0x0008, IP_ACTIVE_HIGH, IPT_UNKNOWN )	// unused?
    PORT_BIT( 0x0010, IP_ACTIVE_HIGH, IPT_COIN12) PORT_NAME("Player 4 Right Coin")
    PORT_BIT( 0x0020, IP_ACTIVE_HIGH, IPT_COIN8 ) PORT_NAME("Player 4 Center Coin")
    PORT_BIT( 0x0040, IP_ACTIVE_HIGH, IPT_COIN4 ) PORT_NAME("Player 4 Left Coin")
    PORT_BIT( 0x0080, IP_ACTIVE_HIGH, IPT_TILT4 )  // slam??
INPUT_PORTS_END



/*************************************
 *
 *  Main CPU memory handlers
 *
 *************************************/

static ADDRESS_MAP_START( main_map, AS_PROGRAM, 16, pred_state )
	AM_RANGE(0x000000, 0x01ffff) AM_ROM
	AM_RANGE(0x400000, 0x40000f) AM_DEVREADWRITE8("6840ptm", ptm6840_device, read, write, 0xff)
	AM_RANGE(0x800000, 0x800001) AM_READ_PORT("systeminp")
	AM_RANGE(0x800008, 0x800009) AM_READ( williams_49way_port_hawk_r )
	AM_RANGE(0x80000a, 0x80000b) AM_READ_PORT("hawkgeneral")
	AM_RANGE(0x80000c, 0x80000d) AM_READ( williams_49way_port_falcon_r )
	AM_RANGE(0x80000e, 0x80000f) AM_READ_PORT("falcongeneral")
	AM_RANGE(0x800010, 0x800011) AM_READ( williams_49way_port_eagle_r )
	AM_RANGE(0x800012, 0x800013) AM_READ_PORT("eaglegeneral")
	AM_RANGE(0x800014, 0x800015) AM_READ( williams_49way_port_condor_r )
	AM_RANGE(0x800016, 0x800017) AM_READ_PORT("condorgeneral")
	AM_RANGE(0x800020, 0x800021) AM_DEVWRITE("hawksnd0", williams_pred_sound_device, sound_w)
	AM_RANGE(0x800022, 0x800023) AM_DEVWRITE("falconsnd0", williams_pred_sound_device, sound_w)
	AM_RANGE(0x800024, 0x800025) AM_DEVWRITE("eaglesnd0", williams_pred_sound_device, sound_w)
	AM_RANGE(0x800026, 0x800027) AM_DEVWRITE("condorsnd0", williams_pred_sound_device, sound_w)
	AM_RANGE(0x800028, 0x800029) AM_DEVWRITE("hawksnd1", williams_pred_sound_device, sound_w)
	AM_RANGE(0x80002a, 0x80002b) AM_DEVWRITE("falconsnd1", williams_pred_sound_device, sound_w)
	AM_RANGE(0x80002c, 0x80002d) AM_DEVWRITE("eaglesnd1", williams_pred_sound_device, sound_w)
	AM_RANGE(0x80002e, 0x80002f) AM_DEVWRITE("condorsnd1", williams_pred_sound_device, sound_w)
	AM_RANGE(0x600000, 0x6000ff) AM_WRITE(blit_param_w)
	AM_RANGE(0xa00000, 0xa00001) AM_WRITE(blit_ctrl_w)
	AM_RANGE(0xc00000, 0xc002ff) AM_RAM AM_SHARE("nvram")
	AM_RANGE(0xfe0000, 0xffffff) AM_RAM
ADDRESS_MAP_END



/*************************************
 *
 *  Misc CPU memory handlers
 *
 *************************************/

static ADDRESS_MAP_START( i8035_map, AS_PROGRAM, 8, pred_state )
	AM_RANGE(0x0000, 0x0fff) AM_ROM
ADDRESS_MAP_END

READ8_MEMBER( pred_state::p1_r )
{
	return 0x6f;
}

READ8_MEMBER( pred_state::p2_r )
{
	return 0x50;
}


READ8_MEMBER( pred_state::io_c_r )
{
	return 0x0a;
}

READ8_MEMBER( pred_state::io_r )
{
	UINT8 ret = 0;
	switch (offset)
	{
		case 1:
			return 0;
		case 5:
			return 0;
		case 9:
			return 2;
		
		case 0x0:
		{
			static int vals[] = { 0x0a, 0x0f };
			static int idx = 0;
			ret = vals[idx];
			idx ^= 1;
			break;
		}
		case 0x4:
		{
			static int vals[] = { 0x0b, 0x0f };
			static int idx = 0;			
			ret = vals[idx];
			idx ^= 1;
			break;

		}
		case 0x8:
		{
			static int vals[] = { 0x01, 0x02, 0x3, 0xff };
			static int idx = 0;
			ret = vals[idx];
			idx = idx % 4;
			break;
		}
	}
	return ret;
}

READ8_MEMBER( pred_state::t1_r )
{
	return 1;
}

WRITE8_MEMBER( pred_state::io_w )
{
//	printf("[%x] %x\n", offset, data);
//	if (offset == 8)
//		printf("\n");
}

WRITE8_MEMBER( pred_state::io_c_w )
{
//	printf("[C] %x\n", data);
}

static ADDRESS_MAP_START( i8035_io_map, AS_IO, 8, pred_state )
	AM_RANGE(0x0000, 0x009) AM_READWRITE(io_r, io_w)
	AM_RANGE(0x000c, 0x00c) AM_READWRITE(io_c_r, io_c_w)
	AM_RANGE(MCS48_PORT_T1, MCS48_PORT_T1) AM_READ(t1_r)
	AM_RANGE(MCS48_PORT_P1, MCS48_PORT_P1) AM_READ(p1_r)
	AM_RANGE(MCS48_PORT_P2, MCS48_PORT_P2) AM_READ(p2_r)
ADDRESS_MAP_END



/*************************************
 *
 *  Main CPU memory handlers
 *
 *************************************/

void pred_state::machine_reset()
{
	for (int i = 0; i < 4; ++i)
	{
		m_screen_state[0].m_swap = 0;
		m_screen_state[0].m_busy = 0;
		m_screen_state[0].m_vram_page = 0;
	}
}



/*************************************
 *
 *  6840 PTM
 *
 *************************************/

WRITE_LINE_MEMBER( pred_state::ptm_irq )
{
	m_maincpu->set_input_line(1, state ? ASSERT_LINE : CLEAR_LINE);
}



/*************************************
 *
 *  Machine driver
 *
 *************************************/

static MACHINE_CONFIG_START( pred, pred_state )

	/* Basic machine hardware */
	MCFG_CPU_ADD("maincpu", M68000, XTAL_8MHz)
	MCFG_CPU_PROGRAM_MAP(main_map)
	MCFG_CPU_VBLANK_INT_DRIVER("hawk", pred_state, vblank_callback)

	MCFG_CPU_ADD("i8035", I8035, XTAL_3_579545MHz)
	MCFG_CPU_PROGRAM_MAP(i8035_map)
	MCFG_CPU_IO_MAP(i8035_io_map)

//	MCFG_MACHINE_START(pred)
	MCFG_NVRAM_ADD_0FILL("nvram")

	MCFG_DEVICE_ADD("6840ptm", PTM6840, 0)
	MCFG_PTM6840_INTERNAL_CLOCK(1000000)
	MCFG_PTM6840_EXTERNAL_CLOCKS(0, 0, 0)
	MCFG_PTM6840_IRQ_CB(WRITELINE(pred_state, ptm_irq))

	/* Video hardware */
	MCFG_DEFAULT_LAYOUT(layout_pred)

	MCFG_SCREEN_ADD("hawk", RASTER)
	MCFG_SCREEN_REFRESH_RATE(60)
	MCFG_SCREEN_VBLANK_TIME(ATTOSECONDS_IN_USEC(500)) // wrong
	MCFG_SCREEN_SIZE(512, 256)
	MCFG_SCREEN_VISIBLE_AREA(48, 436-1, 20, 252-1)
	MCFG_SCREEN_UPDATE_DRIVER(pred_state, screen_update_hawk)
	MCFG_SCREEN_PALETTE("palette")

	MCFG_SCREEN_ADD("falcon", RASTER)
	MCFG_SCREEN_REFRESH_RATE(60)
	MCFG_SCREEN_VBLANK_TIME(ATTOSECONDS_IN_USEC(500))
	MCFG_SCREEN_SIZE(512, 256)
	MCFG_SCREEN_VISIBLE_AREA(48, 436-1, 20, 252-1)
	MCFG_SCREEN_UPDATE_DRIVER(pred_state, screen_update_falcon)
	MCFG_SCREEN_PALETTE("palette")

	MCFG_SCREEN_ADD("eagle", RASTER)
	MCFG_SCREEN_REFRESH_RATE(60)
	MCFG_SCREEN_VBLANK_TIME(ATTOSECONDS_IN_USEC(500))
	MCFG_SCREEN_SIZE(512, 256)
	MCFG_SCREEN_VISIBLE_AREA(48, 436-1, 20, 252-1)
	MCFG_SCREEN_UPDATE_DRIVER(pred_state, screen_update_eagle)
	MCFG_SCREEN_PALETTE("palette")

	MCFG_SCREEN_ADD("condor", RASTER)
	MCFG_SCREEN_REFRESH_RATE(60)
	MCFG_SCREEN_VBLANK_TIME(ATTOSECONDS_IN_USEC(500))
	MCFG_SCREEN_SIZE(512, 256)
	MCFG_SCREEN_VISIBLE_AREA(48, 436-1, 20, 252-1)
	MCFG_SCREEN_UPDATE_DRIVER(pred_state, screen_update_condor)
	MCFG_SCREEN_PALETTE("palette")

	MCFG_PALETTE_ADD("palette", 32 * 4)
	MCFG_PALETTE_INIT_OWNER(pred_state, pred)

	/* Sound hardware */
	MCFG_SPEAKER_STANDARD_MONO("hawkspeaker")
	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("hawksnd0")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "hawkspeaker", 1.0)

	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("hawksnd1")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "hawkspeaker", 1.0)

	MCFG_SPEAKER_STANDARD_MONO("falconspeaker")
	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("falconsnd0")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "falconspeaker", 1.0)

	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("falconsnd1")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "falconspeaker", 1.0)

	MCFG_SPEAKER_STANDARD_MONO("eaglespeaker")
	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("eaglesnd0")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "eaglespeaker", 1.0)

	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("eaglesnd1")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "eaglespeaker", 1.0)

	MCFG_SPEAKER_STANDARD_MONO("condorspeaker")
	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("condorsnd0")

	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "condorspeaker", 1.0)
	MCFG_WILLIAMS_PREDATORS_SOUND_ADD("condorsnd1")
	MCFG_SOUND_ROUTE(ALL_OUTPUTS, "condorspeaker", 1.0)
MACHINE_CONFIG_END



/*************************************
 *
 *  Initialization
 *
 *************************************/

DRIVER_INIT_MEMBER( pred_state, pred )
{

}


/*************************************
 *
 *  ROM definition(s)
 *
 *************************************/

ROM_START( pred )

	/**********************************************************************************************************************
	  Roms from Main board below
	  Contains the 68k, Am2910, NVram etc.  drives all game logic etc.
	 *********************************************************************************************************************/

	ROM_REGION( 0x20000, "maincpu", 0 )
	ROM_LOAD16_BYTE( "u218.bin",   0x000000, 0x8000, CRC(5ed16dc8) SHA1(d50550d7d6e51c0c81972829f4d0a7e4cc20878d) )
	ROM_LOAD16_BYTE( "u219.bin",   0x000001, 0x8000, CRC(752c326b) SHA1(99afbc96c0984e0964937c753efcacf2ff2ade32) )
	ROM_LOAD16_BYTE( "u220.bin",   0x010000, 0x8000, CRC(e1371d17) SHA1(f7c3e9aeb35192d00d83c886a9bf8dc1ec2a5c15) )
	ROM_LOAD16_BYTE( "u237.bin",   0x010001, 0x8000, CRC(8714876b) SHA1(239ad5f28c45c2a2a995e5ed1712fd4da90bb9dc) )

	ROM_REGION( 0x10000, "blitlength", 0 )
	ROM_LOAD( "u201.bin",   0x0000, 0x8000, CRC(2ea40e11) SHA1(73512af40c6739c4061409ee12cf47b7b03b683f) )
	ROM_LOAD( "u203.bin",   0x8000, 0x8000, CRC(9982e4bd) SHA1(a2bbd9883e21bbf8e6d614d4e1ef60d66892236d) )

	ROM_REGION( 0x10000, "blityoffs", 0 )
	ROM_LOAD( "u202.bin",   0x0000, 0x8000, CRC(8deefb05) SHA1(0c1fbf9e1e846dc9bc68a0f8ad505bdec9c08df5) )
	ROM_LOAD( "u204.bin",   0x8000, 0x8000, CRC(0a24750a) SHA1(b40237c0b5165ed7fa30c40bfd42711441c1b8c7) )

	ROM_REGION( 0x10000, "blitattr", 0 )
	ROM_LOAD( "u221.bin",   0x0000, 0x8000, CRC(ce8d42ed) SHA1(7bc014fdfe64c7648ce550e969b23c46aaabace0) )
	ROM_LOAD( "u223.bin",   0x8000, 0x8000, CRC(9b66c1ca) SHA1(d70464fc457671682711eb47523c595ece5cf488) )

	ROM_REGION( 0x10000, "blitxoffs", 0 )
	ROM_LOAD( "u222.bin",   0x0000, 0x8000, CRC(b795c4c2) SHA1(7a6528516f6e28670f25068a293a12f360dc78a1) )
	ROM_LOAD( "u224.bin",   0x8000, 0x8000, CRC(bdba0ed9) SHA1(066f3ee60c1922b6b5f75a9d6083eddf7b673c9b) )

	ROM_REGION( 0x8000, "blitcolour", 0 )
	ROM_LOAD( "u240.bin",   0x0000, 0x8000, CRC(3828b6bc) SHA1(db985977f5d17b45f61c67e8f190581ddf8fee70) )

	ROM_REGION( 0x117, "pal", 0 )
	ROM_LOAD( "u254",   0x0000, 0x117, CRC(8ce4ff25) SHA1(9cbdd85b83eda7f1814e4c0930c4d47ec920a1bf) )

	ROM_REGION( 0x20000, "am2910", 0 ) // microcode for the am2910??
	ROM_LOAD( "u280.bin",   0x0000, 0x200, CRC(835d733a) SHA1(2ea0fe5698a34206e8fc0166e2af4e066d864866) )
	ROM_LOAD( "u281.bin",   0x0000, 0x200, CRC(700b24c1) SHA1(790aa04717e86828974afaa2ac743f37afa11021) )
	ROM_LOAD( "u282.bin",   0x0000, 0x200, CRC(a5005f9a) SHA1(b33ccdc433d299fe3495f5fb2a5e604d8712881f) )
	ROM_LOAD( "u283.bin",   0x0000, 0x200, CRC(8368a869) SHA1(86b2562106d894b63a529ae11c6d7a27347d3654) )

	/**********************************************************************************************************************
	  Roms from SC board below
	  Contains a single rom along with the i8035 and some other bare-bones componenets
	 *********************************************************************************************************************/

	ROM_REGION( 0x1000, "i8035", 0 )
	ROM_LOAD( "u4.bin",   0x0000, 0x1000, CRC(7b9df7a0) SHA1(d8ad5659d18e82815570832b9e159c045e4ac7e6) )


	/**********************************************************************************************************************
	  Roms from Slave boards below
	  All slave boards appear to be identical, I've prefixed rom names with the name of the player each board is for to
	  aid clarity here.
	 *********************************************************************************************************************/

	/* Sound Section */

	/* there are 8 of these.. 2 pairs on each of the 4 slave boards, all running the same program */
	ROM_REGION( 0x10000, "hawksnd0:cpu",   0 )
	ROM_LOAD( "hawk_u84.bin",     0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "hawk_u83.bin",     0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "hawksnd1:cpu",   0 )
	ROM_LOAD( "hawk_u95.bin",     0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "hawk_u96.bin",     0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "falconsnd0:cpu", 0 )
	ROM_LOAD( "falcon_u84.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "falcon_u83.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "falconsnd1:cpu", 0 )
	ROM_LOAD( "falcon_u95.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "falcon_u96.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "eaglesnd0:cpu", 0 )
	ROM_LOAD( "eagle_u84.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "eagle_u83.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "eaglesnd1:cpu", 0 )
	ROM_LOAD( "eagle_u95.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "eagle_u96.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "condorsnd0:cpu", 0 )
	ROM_LOAD( "condor_u84.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "condor_u83.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	ROM_REGION( 0x10000, "condorsnd1:cpu", 0 )
	ROM_LOAD( "condor_u95.bin",   0x0000, 0x8000, CRC(49bf0180) SHA1(40ea3049dd35dc9b306fc516c7b814be025cd39f) )
	ROM_LOAD( "condor_u96.bin",   0x8000, 0x8000, CRC(c34704ce) SHA1(853434087df664ed17e7043804fa9e961c5fe97f) )

	/* Video section */

	/* colour proms are on the slave boards, they're the same on all of them, but we load them once for each board anyway */
	ROM_REGION( 0x40, "hawkproms",   0 )
	ROM_LOAD( "hawk_u77.bin",     0x0000, 0x020, CRC(c9bc35f1) SHA1(78e76cbe72157b775cd24f36e1814e312d56af30) )
	ROM_LOAD( "hawk_u78.bin",     0x0020, 0x020, CRC(3fb02480) SHA1(ace4eeb3a9b81d0890d2eb5c4e3cc2e874cfa88c) )

	ROM_REGION( 0x40, "falconproms", 0 )
	ROM_LOAD( "falcon_u77.bin",   0x0000, 0x020, CRC(c9bc35f1) SHA1(78e76cbe72157b775cd24f36e1814e312d56af30) )
	ROM_LOAD( "falcon_u78.bin",   0x0020, 0x020, CRC(3fb02480) SHA1(ace4eeb3a9b81d0890d2eb5c4e3cc2e874cfa88c) )

	ROM_REGION( 0x40, "eagleproms", 0 )
	ROM_LOAD( "eagle_u77.bin",    0x0000, 0x020, CRC(c9bc35f1) SHA1(78e76cbe72157b775cd24f36e1814e312d56af30) )
	ROM_LOAD( "eagle_u78.bin",    0x0020, 0x020, CRC(3fb02480) SHA1(ace4eeb3a9b81d0890d2eb5c4e3cc2e874cfa88c) )

	ROM_REGION( 0x40, "condorproms", 0 )
	ROM_LOAD( "condor_u77.bin",   0x0000, 0x020, CRC(c9bc35f1) SHA1(78e76cbe72157b775cd24f36e1814e312d56af30) )
	ROM_LOAD( "condor_u78.bin",   0x0020, 0x020, CRC(3fb02480) SHA1(ace4eeb3a9b81d0890d2eb5c4e3cc2e874cfa88c) )

	/* these proms are are also on the slave boards, they're the same on all of them, but we load them once for each board anyway */
	ROM_REGION( 0x400, "hawksincos",   0 )
	ROM_LOAD( "hawk_u4.bin",     0x0000, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )
	ROM_LOAD( "hawk_u5.bin",     0x0200, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )

	ROM_REGION( 0x400, "falconsincos", 0 )
	ROM_LOAD( "falcon_u4.bin",   0x0000, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )
	ROM_LOAD( "falcon_u5.bin",   0x0200, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )

	ROM_REGION( 0x400, "eaglesincos", 0 )
	ROM_LOAD( "eagle_u4.bin",    0x0000, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )
	ROM_LOAD( "eagle_u5.bin",    0x0200, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )

	ROM_REGION( 0x400, "condorsincos", 0 )
	ROM_LOAD( "condor_u4.bin",   0x0000, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )
	ROM_LOAD( "condor_u5.bin",   0x0200, 0x200, CRC(f8aeaa23) SHA1(f1245705a65795be1c15423fda99b3cf2c09200a) )
ROM_END



/*************************************
 *
 *  Game driver(s)
 *
 *************************************/

GAME( 1986, pred, 0, pred, pred, pred_state, pred, ROT0, "Williams / Q Video Systems", "The Predators (prototype)", GAME_IMPERFECT_GRAPHICS )
